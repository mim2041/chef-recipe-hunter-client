import React from 'react';

const FoodsContainer = () => {
    return (
        <div>
            <h1>This is food container</h1>
        </div>
    );
};

export default FoodsContainer;