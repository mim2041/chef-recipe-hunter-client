import React from 'react';

const RecipeDetails = () => {
    return (
        <div>
            
        </div>
    );
};

export default RecipeDetails;